﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Concurrent;
using System.ComponentModel;

namespace FacilityDoorManagement 
{
   public class FacilityDoorManagementService : IDoorManagementService
    {
        //NOTE: Loading static data: We can use Database / files to store and retrive for alter a well in future
        private List<Door> doors = new List<Door>() {
                                                    new Door { ID="1",DoorType="Entry",IsLocked=true,CustomLable="",IsOpen=false,Name="Main Entrace1"},
                                                    new Door { ID="2",DoorType="Entry",IsLocked=false,CustomLable="",IsOpen=true,Name="Main Entrace2"},
                                                    new Door { ID="3",DoorType="Entry",IsLocked=false,CustomLable="",IsOpen=false,Name="Main Entrace3"},
                                                    new Door { ID="4",DoorType="Exit",IsLocked=true,CustomLable="",IsOpen=false,Name="Exit LiftLobby1"},
                                                    new Door { ID="5",DoorType="Exit",IsLocked=false,CustomLable="",IsOpen=true,Name="Exit LiftLobby1"},
                                                    new Door { ID="6",DoorType="Exit",IsLocked=false,CustomLable="",IsOpen=false,Name="Exit LiftLobby1"}
                                                    };

        //NOTE: Aquiring locks in-order make it thread safe when multiple clients query
        //NOTE: We can also achive this using concurrent collections
        Object lockObj = new object();





        public FacilityDoorManagementService()
        {

        }
        public string AddNewDoor(Door newDoor)
        {
            lock (lockObj)
            {
                if (newDoor != null)
                {
                    //NOTE: Auto generating ID(Can be improved)
                    newDoor.ID = ( doors.Count + 1).ToString();
                    this.doors.Add(newDoor);
                    return newDoor.ID;
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        public List<Door> GetListOfAvailableDoors()
        {
            return this.doors;
        }

        public bool IsDoorLocked(string doorID)
        {
            lock (lockObj)
            {
                if (!string.IsNullOrEmpty(doorID))
                {
                    var door = doors.Where(x => x.ID == doorID).FirstOrDefault();
                    if (door != null)
                    {
                        return door.IsLocked;
                    }
                    else
                    {
                        throw new Exception("No such door found");
                    }
                }
                else
                {
                    throw new Exception("No such door found");
                }
            }
        }

        public bool IsDoorOpen(string doorID)
        {
            lock (lockObj)
            {
                if (!string.IsNullOrEmpty(doorID))
                {
                    var door = doors.Where(x => x.ID == doorID).FirstOrDefault();
                    if (door != null)
                    {
                        return door.IsOpen;
                    }
                    else
                    {
                        throw new Exception("No such door found");
                    }
                }
                else
                {
                    throw new Exception("No such door found");
                }
            }
        }

        public string RemoveDoor(string doorID)
        {
            lock (lockObj)
            {
                if (!string.IsNullOrEmpty(doorID))
                {
                    var door = doors.Where(x => x.ID == doorID).FirstOrDefault();
                    if (door != null)
                    {
                        this.doors.Remove(door);
                        return door.ID;
                    }
                    else
                    {
                        throw new Exception("No such door found");
                    }
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        public void SaveModificationsToDoors(List<Door> modifiedDoors)
        {
            //NOTE: This code can be improvised once we have DB in place. May be using Entity framework
            foreach (var item in modifiedDoors)
            {
                var doorCurrent = doors.Find(x => x.ID == item.ID);
                if (doorCurrent!=null)
                {
                    doors.Where(x => x.ID == doorCurrent.ID).FirstOrDefault().IsLocked = item.IsLocked;
                    doors.Where(x => x.ID == doorCurrent.ID).FirstOrDefault().IsOpen = item.IsOpen;
                    doors.Where(x => x.ID == doorCurrent.ID).FirstOrDefault().Name = item.Name;
                    doors.Where(x => x.ID == doorCurrent.ID).FirstOrDefault().CustomLable = item.CustomLable;
                    doors.Where(x => x.ID == doorCurrent.ID).FirstOrDefault().DoorType = item.DoorType;
                }
                else
                {
                    AddNewDoor(item);
                }
            }
        }

        public string SetDoorToClosed(string doorID)
        {
            lock (lockObj)
            {
                if (!string.IsNullOrEmpty(doorID))
                {
                    var door = doors.Where(x => x.ID == doorID).FirstOrDefault();
                    if (door != null)
                    {
                        door.IsOpen = false;
                        return door.ID;
                    }
                    else
                    {
                        throw new Exception("No such door found");
                    }
                }
                else
                {
                    throw new Exception("doorID null");
                }
            }
        }

        public string SetDoorToLocked(string doorID)
        {
            lock (lockObj)
            {
                if (!string.IsNullOrEmpty(doorID))
                {
                    var door = doors.Where(x => x.ID == doorID).FirstOrDefault();
                    if (door != null)
                    {
                        door.IsLocked = true;
                        return door.ID;
                    }
                    else
                    {
                        throw new Exception("No such door found");
                    }
                }
                else
                {
                    throw new Exception("doorID null");
                }
            }
        }

        public string SetDoorToOpen(string doorID)
        {
            lock (lockObj)
            {
                if (!string.IsNullOrEmpty(doorID))
                {
                    var door = doors.Where(x => x.ID == doorID).FirstOrDefault();
                    if (door != null)
                    {
                        door.IsOpen = true;
                        return door.ID;
                    }
                    else
                    {
                        throw new Exception("No such door found");
                    }
                }
                else
                {
                    throw new Exception("doorID null");
                }
            }
        }

        public string SetDoorToUnlocked(string doorID)
        {
            lock (lockObj)
            {
                if (!string.IsNullOrEmpty(doorID))
                {
                    var door = doors.Where(x => x.ID == doorID).FirstOrDefault();
                    if (door != null)
                    {
                        door.IsLocked = false;
                        return door.ID;
                    }
                    else
                    {
                        throw new Exception("No such door found");
                    }
                }
                else
                {
                    throw new Exception("doorID null");
                }
            }
        }
    }
}
