﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace FacilityDoorManagement
{
    // NOTE : Have made this as session mode so that single instance is created and maintained JUST for DEMO. We can remove once have real Database in place which will preserve data
    [ServiceContract(SessionMode = SessionMode.Required)]
    public interface IDoorManagementService
    {
        [OperationContract]
        string AddNewDoor(Door newDoor);
        [OperationContract]
        string RemoveDoor(string doorID);

        [OperationContract]
        List<Door> GetListOfAvailableDoors();

        [OperationContract]
        bool IsDoorOpen(string doorID);

        [OperationContract]
        bool IsDoorLocked(string doorID);

        [OperationContract]
        string SetDoorToOpen(string doorID);

        [OperationContract]
        string SetDoorToClosed(string doorID);

        [OperationContract]
        string SetDoorToLocked(string doorID);

        [OperationContract]
        string SetDoorToUnlocked(string doorID);

        [OperationContract]
        void SaveModificationsToDoors(List<Door> modifiedDoors);

    }
}
