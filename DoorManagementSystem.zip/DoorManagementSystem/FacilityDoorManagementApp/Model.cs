﻿using FacilityDoorManagementApp.FacilityDoorManagementServiceReference;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FacilityDoorManagementApp
{
    class Model
    {
        DoorManagementServiceClient client;
        public Model()
        {
            client = new DoorManagementServiceClient();
        }

        public List<FacilityDoorManagementServiceReference.Door> GetAllAvialableDoors()
        {
            return client.GetListOfAvailableDoors().ToList();
        }

        public bool IsDoorLocked(string doorID)
        {
            return client.IsDoorLocked(doorID);
        }

        public bool IsDoorOpen(string doorID)
        {
            return client.IsDoorOpen(doorID);
        }

        public string RemoveDoor(string doorID)
        {
            return client.RemoveDoor(doorID);
        }

        public string SetDoorToClosed(string doorID)
        {
            return client.SetDoorToClosed(doorID);
        }

        public string SetDoorToLocked(string doorID)
        {
            return client.SetDoorToLocked(doorID);
        }

        public string SetDoorToOpen(string doorID)
        {
            return client.SetDoorToOpen(doorID);
        }

        public string SetDoorToUnlocked(string doorID)
        {
            return client.SetDoorToLocked(doorID);
        }

        internal void SaveChangesToDoors(List<Door> listOfDoorsInFacility)
        {
            client.SaveModificationsToDoors(listOfDoorsInFacility.ToArray());
        }

        internal void AddNewDoor(Door newDoor)
        {
            client.AddNewDoor(newDoor);
        }
    }
}
