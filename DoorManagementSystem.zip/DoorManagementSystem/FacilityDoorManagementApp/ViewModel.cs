﻿using FacilityDoorManagementApp.FacilityDoorManagementServiceReference;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;

namespace FacilityDoorManagementApp
{
    class ViewModel : INotifyPropertyChanged
    {
        public ObservableCollection<FacilityDoor> listOfDoors = new ObservableCollection<FacilityDoor>();
        private Model model = null;
        private readonly Command loadAllDoors;
        private readonly Command addNewDoor;
        private readonly Command removeDoor;
        private readonly Command saveChanges;

        public ObservableCollection<string> userOptions = new ObservableCollection<string> { "View Doors", "Configure Door", "Modify Door" };

        public ObservableCollection<string> ListOfUserOptions
        {
            get { return userOptions; }
            set
            {
                userOptions = value;
                PropertyChanged(this, new PropertyChangedEventArgs("ListOfUserOptions"));
            }
        }
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = this.PropertyChanged;
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public ICommand LoadAllDoorsCommand => loadAllDoors;

        public ICommand AddNewDoorCommand => addNewDoor;

        public ICommand RemoveDoor => removeDoor;

        public ICommand SaveChangesCommand => saveChanges;

        public ObservableCollection<FacilityDoor> ListOfDoorsInFacility
        {
            get { return listOfDoors; }
            set
            {
                listOfDoors = value;
                PropertyChanged(this, new PropertyChangedEventArgs("ListOfDoorsInFacility"));
            }
        }

        public ViewModel()
        {
            model = new Model();
            loadAllDoors = new Command(GetAllDoors);
            addNewDoor = new Command(AddNewDoor);
            removeDoor = new Command(DeleteDoor);
            saveChanges = new Command(SaveChanges);
        }

        private void SaveChanges()
        {
            model.SaveChangesToDoors(GetServerTypeDataHelper());
            GetAllDoors();
        }

        private bool changesMade = false;
        public bool ChangedMade
        {
            get
            {
                return changesMade;
            }
            set
            {
                changesMade = value;
                OnPropertyChanged("ChangedMade");
            }
        }

        private FacilityDoor seletedItem = null;
        public FacilityDoor SeletedDoor
        {
            get
            {
                return seletedItem;
            }
            set
            {
                seletedItem = value;
                OnPropertyChanged("SeletedDoor");
            }
        }

        private string userOption=string.Empty;

        public string UserOptionSeleted
        {
            get
            {
                return userOption;
            }
            set
            {
                userOption = value;
                UpdateUserButtons(userOption);
                
                OnPropertyChanged("UserOptionSeleted");
            }
        }

        private void UpdateUserButtons(string userOption)
        {
            if (string.IsNullOrEmpty(userOption))
            {
                return;
            }
            if (string.Compare(userOption,"view doors",true)==0)
            {
                this.EnableLoadDoors = true;
                this.EnableAddRemoveDoors = false;
            }
            else
            {
                MessageBox.Show("Make sure you have required permissions..!","Warning");
                this.EnableLoadDoors = true;
                this.EnableAddRemoveDoors = true;
            }
        }

        private bool enableLoadDoor = false;
        public bool EnableLoadDoors
        {
            get
            {
                return enableLoadDoor;
            }
            set
            {
                enableLoadDoor = value;
                OnPropertyChanged("EnableLoadDoors");
            }
        }

        private bool enableAddRemoveDoor = false;
        public bool EnableAddRemoveDoors
        {
            get
            {
                return enableAddRemoveDoor;
            }
            set
            {
                enableAddRemoveDoor = value;
                OnPropertyChanged("EnableAddRemoveDoors");
            }
        }


        private string customLabel = string.Empty;
        public string NewDoorCustomLabel
        {
            get
            {
                return customLabel;
            }
            set
            {
                customLabel = value;
                OnPropertyChanged("NewDoorCustomLabel");
            }
        }

        private string name = string.Empty;
        public string NewDoorName
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
                OnPropertyChanged("NewDoorName");
            }
        }

        private bool isOpen = false;
        public bool IsNewDoorOpen
        {
            get
            {
                return isOpen;
            }
            set
            {
                isOpen = value;
                OnPropertyChanged("IsNewDoorOpen");
            }
        }

        private bool isLocked = true;
        public bool IsNewDoorLocked
        {
            get
            {
                return isLocked;
            }
            set
            {
                isLocked = value;
                OnPropertyChanged("IsNewDoorLocked");
            }
        }


        private void DeleteDoor()
        {
            if (SeletedDoor != null)
            {
                model.RemoveDoor(SeletedDoor.ID);
                //Refresh the UI with Latest data
                Dispatcher.CurrentDispatcher.Invoke(() => { GetAllDoors(); });
            }
            else
            {
                MessageBox.Show("No Item Selected..!", "Warning");
            }
        }

        private void AddNewDoor()
        {
            ListOfDoorsInFacility.Add(new FacilityDoor { CustomLabel = "default", IsLocked = false, IsOpen = false, ID = string.Empty, Name = "New Door" });
        }

        //NOTE: Can be improved

        private void GetAllDoors()
        {
            ListOfDoorsInFacility.Clear();
            DataHelperServerToClient(model.GetAllAvialableDoors());
        }

        private void DataHelperServerToClient(List<Door> ListOfDoorsInFacilityFromServer)
        {

            foreach (var item in ListOfDoorsInFacilityFromServer)
            {
                ListOfDoorsInFacility.Add(new FacilityDoor { CustomLabel = item.CustomLable, IsLocked = item.IsLocked, IsOpen = item.IsOpen, ID = item.ID, Name = item.Name });
            }
        }

        private List<FacilityDoorManagementServiceReference.Door> GetServerTypeDataHelper()
        {
            var serverList = new List<FacilityDoorManagementServiceReference.Door>();
            foreach (var item in ListOfDoorsInFacility)
            {
                serverList.Add(new Door { CustomLable = item.CustomLabel, IsLocked = item.IsLocked, IsOpen = item.IsOpen, ID = item.ID, Name = item.Name });
            }
            return serverList;
        }
    }
}
