﻿using System.Runtime.Serialization;

namespace FacilityDoorManagement
{
    [DataContract]
    public class Door 
    {
        [DataMember(IsRequired = true,Order =1)]
        public string Name { get; set; }

        [DataMember(IsRequired =true)]
        public string ID { get; set; }

        [DataMember]
        public string CustomLable { get; set; }

        [DataMember]
        public bool IsOpen { get; set; }

        [DataMember]
        public bool IsLocked { get; set; }

        [DataMember]
        public string DoorType { get; set; }
    }

    //NOTE: We shall restric who can add/remove, view the doors based on the access permissions
    public enum UserType
    {
        GeneralUser=0,
        SecurityIncharge,
        SecurityHead
    }
}